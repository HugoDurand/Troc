create function st_rastertoworldcoordy(rast raster, xr integer, yr integer)
  returns double precision
immutable
strict
parallel safe
language sql
as $$
SELECT latitude FROM public._ST_rastertoworldcoord($1, $2, $3)
$$;

comment on function st_rastertoworldcoordy(raster, integer, integer)
is 'args: rast, xcolumn, yrow - Returns the geometric Y coordinate upper left corner of a raster, column and row. Numbering of columns and rows starts at 1.';

alter function st_rastertoworldcoordy(raster, integer, integer)
  owner to postgres;

