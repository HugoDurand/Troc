create function st_mapalgebrafct(rast raster, onerastuserfunc regprocedure)
  returns raster
language sql
as $$
SELECT public.ST_mapalgebrafct($1, 1, NULL, $2, NULL)
$$;

alter function st_mapalgebrafct(raster, regprocedure)
  owner to postgres;

