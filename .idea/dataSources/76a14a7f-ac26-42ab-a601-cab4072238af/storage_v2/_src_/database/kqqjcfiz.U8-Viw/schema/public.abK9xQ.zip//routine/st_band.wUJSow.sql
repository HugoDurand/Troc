create function st_band(rast raster, nband integer)
  returns raster
immutable
strict
parallel safe
language sql
as $$
SELECT  public.ST_band($1, ARRAY[$2])
$$;

comment on function st_band(raster, integer)
is 'args: rast, nband - Returns one or more bands of an existing raster as a new raster. Useful for building new rasters from existing rasters.';

alter function st_band(raster, integer)
  owner to postgres;

