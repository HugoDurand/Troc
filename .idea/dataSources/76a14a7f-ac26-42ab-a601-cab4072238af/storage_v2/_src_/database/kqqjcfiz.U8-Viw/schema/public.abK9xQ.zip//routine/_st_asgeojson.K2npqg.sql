create function "_st_asgeojson"(integer, geometry, integer, integer)
  returns text
immutable
strict
parallel safe
language sql
as $$
SELECT public.ST_AsGeoJson($2::public.geometry, $3::int4, $4::int4);
$$;

alter function "_st_asgeojson"(integer, geometry, integer, integer)
  owner to postgres;

