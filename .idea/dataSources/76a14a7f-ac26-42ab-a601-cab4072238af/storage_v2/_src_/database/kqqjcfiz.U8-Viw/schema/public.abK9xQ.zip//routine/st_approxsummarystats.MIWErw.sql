create function st_approxsummarystats(rast raster, nband integer DEFAULT 1, exclude_nodata_value boolean DEFAULT true, sample_percent double precision DEFAULT 0.1)
  returns summarystats
immutable
strict
parallel safe
language sql
as $$
SELECT public._ST_summarystats($1, $2, $3, $4)
$$;

alter function st_approxsummarystats(raster, integer, boolean, double precision)
  owner to postgres;

