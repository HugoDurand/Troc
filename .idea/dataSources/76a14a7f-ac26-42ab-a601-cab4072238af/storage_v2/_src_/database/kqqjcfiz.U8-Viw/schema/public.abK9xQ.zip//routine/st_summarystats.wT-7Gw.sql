create function st_summarystats(rast raster, nband integer DEFAULT 1, exclude_nodata_value boolean DEFAULT true)
  returns summarystats
immutable
strict
parallel safe
language sql
as $$
SELECT public._ST_summarystats($1, $2, $3, 1)
$$;

comment on function st_summarystats(raster, integer, boolean)
is 'args: rast, nband, exclude_nodata_value - Returns summarystats consisting of count, sum, mean, stddev, min, max for a given raster band of a raster or raster coverage. Band 1 is assumed is no band is specified.';

alter function st_summarystats(raster, integer, boolean)
  owner to postgres;

