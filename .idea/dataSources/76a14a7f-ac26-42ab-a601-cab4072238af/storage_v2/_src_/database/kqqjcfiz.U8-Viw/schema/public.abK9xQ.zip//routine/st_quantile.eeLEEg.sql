create function st_quantile(rastertable text, rastercolumn text, nband integer, quantile double precision)
  returns double precision
stable
strict
language sql
as $$
SELECT ( public._ST_quantile($1, $2, $3, TRUE, 1, ARRAY[$4]::double precision[])).value
$$;

alter function st_quantile(text, text, integer, double precision)
  owner to postgres;

