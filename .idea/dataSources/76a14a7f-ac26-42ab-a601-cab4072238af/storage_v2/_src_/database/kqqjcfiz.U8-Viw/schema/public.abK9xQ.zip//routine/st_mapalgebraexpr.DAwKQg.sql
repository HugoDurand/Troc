create function st_mapalgebraexpr(rast raster, pixeltype text, expression text, nodataval double precision DEFAULT NULL::double precision)
  returns raster
language sql
as $$
SELECT public.ST_mapalgebraexpr($1, 1, $2, $3, $4)
$$;

alter function st_mapalgebraexpr(raster, text, text, double precision)
  owner to postgres;

