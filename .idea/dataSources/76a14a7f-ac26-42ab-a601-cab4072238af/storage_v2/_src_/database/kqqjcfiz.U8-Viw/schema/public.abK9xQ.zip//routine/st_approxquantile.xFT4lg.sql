create function st_approxquantile(rast raster, quantile double precision)
  returns double precision
immutable
parallel safe
language sql
as $$
SELECT ( public._ST_quantile($1, 1, TRUE, 0.1, ARRAY[$2]::double precision[])).value
$$;

alter function st_approxquantile(raster, double precision)
  owner to postgres;

